from django.contrib import admin

from aiz_employee_training.models import EmployeeTraining

# Register your models here.
admin.site.register(EmployeeTraining)