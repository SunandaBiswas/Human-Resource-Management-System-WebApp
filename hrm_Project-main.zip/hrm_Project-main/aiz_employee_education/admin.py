from django.contrib import admin

from aiz_employee_education.models import EmployeeEducation

# Register your models here.
admin.site.register(EmployeeEducation)