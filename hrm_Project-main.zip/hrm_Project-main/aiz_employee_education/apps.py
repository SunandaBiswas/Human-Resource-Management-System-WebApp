from django.apps import AppConfig


class AizEmployeeEducationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'aiz_employee_education'
