from django.contrib import admin

from aiz_job_reference.models import JobReference

# Register your models here.
admin.site.register(JobReference)