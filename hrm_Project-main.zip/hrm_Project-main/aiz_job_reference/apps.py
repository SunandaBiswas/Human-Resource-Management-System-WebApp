from django.apps import AppConfig


class AizJobReferenceConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'aiz_job_reference'
