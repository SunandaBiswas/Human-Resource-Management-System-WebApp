from django.apps import AppConfig


class AizJobExperiencesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'aiz_job_experiences'
