from django.contrib import admin

from aiz_job_experiences.models import EmployeeJobExperiences

# Register your models here.
admin.site.register(EmployeeJobExperiences)