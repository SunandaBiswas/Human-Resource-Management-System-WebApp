"""
init.py
"""

from aiz import (
    aiz_apps,
    aiz_context_processors,
    aiz_middlewares,
    aiz_settings,
    haystack_configuration,
    rest_conf,
)
