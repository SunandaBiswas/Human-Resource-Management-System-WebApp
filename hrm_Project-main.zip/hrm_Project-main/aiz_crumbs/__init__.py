from aiz_crumbs import settings
